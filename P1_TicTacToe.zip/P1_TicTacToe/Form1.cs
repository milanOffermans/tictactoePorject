namespace WinFormsTickTackTo
{
    public partial class Gameform : Form
    {
        private const string circle = "o";

        private const string circleWinText = "circle has won";

        private const string cross = "x";

        private const string crossWinText = "cross has won";

        private const int maximalTurnCount = 9;

        private const int minimalTurnCount = 5;

        private readonly int[] fields = {0,0,0,
                               0,0,0,
                               0,0,0};

        private int timesButtonPressed;
        private string valueOfField = string.Empty;

        public Gameform()
        {
            InitializeComponent();
            checkCircle.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e) => OnButtonClickHandler(button1, 0);

        private void button2_Click(object sender, EventArgs e) => OnButtonClickHandler(button2, 1);

        private void button3_Click(object sender, EventArgs e) => OnButtonClickHandler(button3, 2);

        private void button4_Click(object sender, EventArgs e) => OnButtonClickHandler(button4, 3);

        private void button5_Click(object sender, EventArgs e) => OnButtonClickHandler(button5, 4);

        private void button6_Click(object sender, EventArgs e) => OnButtonClickHandler(button6, 5);

        private void button7_Click(object sender, EventArgs e) => OnButtonClickHandler(button7, 6);

        private void button8_Click(object sender, EventArgs e) => OnButtonClickHandler(button8, 7);

        private void button9_Click(object sender, EventArgs e) => OnButtonClickHandler(button9, 8);

        private void buttonRestart_Click(object sender, EventArgs e)
        {
            for (var i = 0; i < fields.Length; i++)
            {
                fields[i] = 0;
            }

            labelResult.Text = string.Empty;
            timesButtonPressed = 0;

            var buttons = GetButtons();

            for (var i = 0; i < buttons.Length; i++)
            {
                buttons[i].Text = string.Empty;
                buttons[i].Enabled = true;
            }
        }

        private void DisableButtons()
        {
            var mybutton = GetButtons();

            for (var i = 0; i < mybutton.Length; i++)
            {
                mybutton[i].Enabled = false;
            }
        }

        private Button[] GetButtons() => new[] { button1, button2, button3, button4, button5, button6, button7, button8, button9 };

        private void HandleGameProgress()
        {
            if (timesButtonPressed >= minimalTurnCount)
            {
                if (timesButtonPressed >= maximalTurnCount)
                {
                    labelResult.Text = "its a draw";
                }

                //vertical
                if (fields[0] == 1 && fields[3] == 1 && fields[6] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[0] == 2 && fields[3] == 2 && fields[6] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }
                else if (fields[1] == 1 && fields[4] == 1 && fields[7] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[1] == 2 && fields[4] == 2 && fields[7] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }
                else if (fields[2] == 1 && fields[5] == 1 && fields[8] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[2] == 2 && fields[5] == 2 && fields[8] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }

                //horizontal
                else if (fields[0] == 1 && fields[1] == 1 && fields[2] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[0] == 2 && fields[1] == 2 && fields[2] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }
                else if (fields[3] == 1 && fields[4] == 1 && fields[5] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[3] == 2 && fields[4] == 2 && fields[5] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }
                else if (fields[6] == 1 && fields[7] == 1 && fields[8] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[6] == 2 && fields[7] == 2 && fields[8] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }

                //diagonal
                else if (fields[0] == 1 && fields[4] == 1 && fields[8] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[0] == 2 && fields[4] == 2 && fields[8] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }
                else if (fields[2] == 1 && fields[4] == 1 && fields[6] == 1)
                {
                    labelResult.Text = crossWinText;
                    DisableButtons();
                }
                else if (fields[2] == 2 && fields[4] == 2 && fields[6] == 2)
                {
                    labelResult.Text = circleWinText;
                    DisableButtons();
                }
            }
        }

        private void OnButtonClickHandler(Button button, int fieldindex)
        {
            SwichtPlayers();
            button.Text = valueOfField;
            button.Enabled = false;
            timesButtonPressed++;

            if (valueOfField == cross)
            {
                fields[fieldindex] = 1;
            }
            else
            {
                fields[fieldindex] = 2;
            }

            HandleGameProgress();
        }

        private void SwichtPlayers()
        {
            if (valueOfField == circle)
            {
                valueOfField = cross;
                checkCircle.Checked = true;
                checkCross.Checked = false;
            }
            else
            {
                valueOfField = circle;
                checkCross.Checked = true;
                checkCircle.Checked = false;
            }
        }
    }
}
